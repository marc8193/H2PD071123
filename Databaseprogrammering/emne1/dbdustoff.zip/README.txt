SQL eksempler til en biblioteksdatabase
1. Installér DB Browser (SQLite browser)
2. Åben databsen library.db
3. Prøv eksemplerne af
4. Opgave:
	Chefen: Albert vil hverken være kvinde ellers mand! Vi må opdatere databasen
	Dig: Albert hvem?
	Chefen: Øh. Efternavnet startede med C og hun gik vist i 9. klasse
	1. Find id'et på den pågældende elev
	2. Opdater feltet gender til 'N' hvor id'et stemmer
5. AFLEVERES I MOODLE: Find eleven via en SQL forespørgsel
	Eleven er født i 2000 og går i en A klasse. Eleven har lånt over 12 bøger og en af dem var "Self Reliance"


